package mapper;

import org.apache.ibatis.annotations.*;
import pojo.dao.Good;
import pojo.dao.User;

import java.util.List;

public interface UserMapper {
    //根据用户名、密码、用户身份查询用户对象，用于用户登录
    @Select("Select * from tb_user where username=#{username} and password=#{password} and status=#{status}")
    User select(@Param("username") String username, @Param("password") String password,@Param("status")int status);

    //插入用户对象，用于用户注册
    @Select("insert into tb_user values(null,#{username},#{password},#{status},#{email})")
    void add(User user);
    //根据用户名查找用户，用于注册时防止重命名
    @Select("Select * from tb_user where username=#{username}")
    User selectByUsername(@Param("username") String username);

    //删除用户对象，用于用户注销
    @Delete("delete from tb_user where id=#{id}")
    void deleteUserById(int id);
    //修改用户个人信息
    @Update("update tb_user set username = #{username}, password = #{password}, email = #{email}, status = #{status} where id =#{id}")
    void update(User user);

    //根据身份查询用户数量，管理员用
    @Select("Select count(*) from tb_user where status=#{status}")
    int selectNumberByStatus(int status);

    //查询用户（分页+动态条件查询），管理员用
    List<User> selectByPageAndStatus(@Param("begin") int begin, @Param("size") int size, @Param("u")User user);
    int selectCountByStatus(@Param("u")User user);

    //根据用户名找id
    @Select("Select id from tb_user where username=#{username}")
    int selectIdByUsername(@Param("username") String username);



}
