package mapper;

import org.apache.ibatis.annotations.*;
import pojo.dao.Orders;


import java.util.List;

public interface OrdersMapper {
    //提交账单（之后要提交账单中的项）
    @Insert("insert into tb_orders values (#{id},#{money},#{receiverAddress},#{receiverName},#{receiverPhone},#{orderTime},#{userId},#{status})")
    @ResultMap("ordersResultMap")
    void add(Orders orders);

    //删除账单（要先删除账单中的项）
    @Delete("delete from tb_orders where id=#{id}")
    @ResultMap("ordersResultMap")
    void deleteById(String id);

    //查询个人账单
    @Select("select * from tb_orders where user_id = #{userId}")
    @ResultMap("ordersResultMap")
    List<Orders> selectByUserId(int userId);

    //查询所有账单
    @Select("select * from tb_orders")
    @ResultMap("ordersResultMap")
    List<Orders> selectAllOrders();

    //修改订单状态，用于确定收发货
    @Update("update tb_orders set status = #{status} where id = #{id}")
    @ResultMap("ordersResultMap")
    void updateStatus(@Param("id") String id, @Param("status") int status);

    //查询订单金额，计算营收

    Float selectMoneyInt();

}
