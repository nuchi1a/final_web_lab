package mapper;


import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import pojo.dao.Good;
import pojo.dao.Notice;

import java.util.List;

public interface NoticeMapper {

    @Insert("insert into notice values(null, #{title},#{details},#{publisher},#{nTime})")
    @ResultMap("noticeResultMap")
    void addNotice(Notice notice);
    @Delete("delete from notice where n_id=#{nId}")
    @ResultMap("noticeResultMap")
    void removeNotice(int nId);
    @Select("select * from notice where n_id=#{nId}")
    @ResultMap("noticeResultMap")
    Notice selectNotice(int nId);
    @Select("select * from notice")
    @ResultMap("noticeResultMap")
    List<Notice> selectNotices();



}