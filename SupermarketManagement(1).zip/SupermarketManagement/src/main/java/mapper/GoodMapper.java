package mapper;

import org.apache.ibatis.annotations.*;
import pojo.dao.Good;

import java.util.List;

public interface GoodMapper {
    //分页动态条件查询
    List<Good> selectByPageAndCondition(@Param("begin") int begin, @Param("size") int size, @Param("good") Good good);
    //分页动态查询的获得的总记录数
    int selectTotalCountByCondition(Good good);

    //添加商品
    @Insert("insert into tb_good values(null,#{goodName},#{companyName},#{salePrice},#{inPrice},#{inDate},#{num},#{description},#{status})")
    @ResultMap("goodResultMap")
    void add(Good good);

    //根据id查询商品
    @Select("select * from tb_good where id = #{id}")
    @ResultMap("goodResultMap")
    Good selectById(int id);

    //更新商品信息
    @Update("update tb_good set good_name = #{goodName}, company_name = #{companyName}, sale_price = #{salePrice}, " +
            "in_price = #{inPrice},num = #{num},description = #{description}, status = #{status} where id =#{id}")
    @ResultMap("goodResultMap")
    void update(Good good);

    @Delete("delete from tb_good where id=#{id}")
    @ResultMap("goodResultMap")
    void deleteById(int id);

    @Update("update tb_good set ordered = #{ordered} where id=#{id}")
    @ResultMap("goodResultMap")
    void updateNum(Good good);

    //分页查询
    @Select("select * from tb_good limit #{begin}, #{size}")
    @ResultMap("goodResultMap")
    List<Good> selectByPage(@Param("begin") int begin, @Param("size") int size);

    //查询总记录数
    @Select("select count(*) from tb_good ")
    int selectTotalCount();

    //根据id批量删除
    void deleteByIds(@Param("ids") int[] ids);


    List<Good> selectHotGoods();
    List<Good> selectGoodsSaleNumber7();
    List<Good> selectGoodsSaleNumber30();
    List<Good> selectGoodsSaleNumber365();
}
