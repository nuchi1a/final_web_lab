package mapper;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import pojo.dao.Good;
import pojo.dao.OrderItem;

import java.util.List;

public interface OrderItemMapper {
    //每次添加账单的同时，也要添加对应账单内的商品
    @Insert("insert into orderitem values(#{orderId},#{goodId},#{buyNum},#{spend})")
    @ResultMap("orderItemResultMap")
    void addItems(OrderItem item);

    //删除账单前，要先删除对应商品
    @Delete("delete from orderitem where order_id=#{orderId}")
    @ResultMap("orderItemResultMap")
    void deleteByOrderIdAfter(String orderId);


    @Select("select * from orderitem where order_id=#{orderId}")
    @ResultMap("orderItemResultMap")
    List<OrderItem> getOrderItemByOrderId(String orderId);




}
