package mapper;



import org.apache.ibatis.annotations.*;
import pojo.dao.EmployeeInfo;
import pojo.dao.Good;

public interface EmployeeInfoMapper {
    //注册用户为雇员时增加雇员信息表
    @Insert("insert into employee_info values(#{employeeId},#{name},#{age},#{sex},#{job},#{phone},#{state},#{salary},#{commission})")
    @ResultMap("employeeInfoResultMap")
    void addEmployeeInfo(EmployeeInfo employeeInfo);
    //查询个人信息
    @Select("select * from employee_info where employee_id=#{employeeId}")
    @ResultMap("employeeInfoResultMap")
    EmployeeInfo selectEmployeeInfo(int employeeId);
    //修改个人信息（雇员用）
    @Update("update employee_info set name=#{name}, age=#{age}, sex=#{sex}, job=#{job}, phone=#{phone},state=#{state} where employee_id=#{employeeId}")
    @ResultMap("employeeInfoResultMap")
    void updateEmployeeInfo(EmployeeInfo employeeInfo);
    //修改薪资和提成（管理员用）
    @Update("update employee_info set salary=#{salary} where employee_id=#{employeeId}")
    @ResultMap("employeeInfoResultMap")
    void updateSalary(@Param("employeeId") int employeeId,@Param("salary") float salary);

    @Update("update employee_info set commission=#{commission} where employee_id=#{employeeId}")
    @ResultMap("employeeInfoResultMap")
    void updateCommission(@Param("employeeId") int employeeId,@Param("commission") float commission);
    //修改状态（雇员打卡、签退、请假）
    @Update("update employee_info set state=#{state} where employee_id=#{employeeId}")
    @ResultMap("employeeInfoResultMap")
    void updateState(@Param("employeeId") int employeeId, @Param("state")int state);
    //删除雇员用户时删除雇员的个人信息
    @Delete("delete from employee_info where employee_id=#{employeeId}")
    @ResultMap("employeeInfoResultMap")
    void removeEmployeeInfo(int employeeId);



}
