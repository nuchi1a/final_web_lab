package service;

import pojo.bean.PageBean;
import pojo.dao.Good;
import pojo.dao.Notice;

import java.util.List;

public interface NoticeService {
    //发布公告
    public void addNotice(Notice notice);
    //查询所有公告
    public List<Notice> selectAll();
    //删除公告
    public void deleteNotice(int id);
    //查看指定公告
    public Notice getNotice(int id);
}
