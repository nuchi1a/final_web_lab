package service;

import pojo.bean.PageBean;
import pojo.dao.EmployeeInfo;
import pojo.dao.User;

public interface UserService {
    //用户登录
    public User login(String username, String password,int status);
    //用户注册
    public boolean register(User user);
    //用户注册时雇员信息录入
    public void enter(EmployeeInfo info);
    //用户注销
    public void deleteById(int id);
    //用户注销时雇员信息删除
    public void deleteByEmployeeId(int id);
    //根据身份查询用户数量
    public int selectNumberByStatus(int status);
    //查询用户（分页，动态条件查询），管理员使用
    PageBean<User> selectUsersByPageAndStatus(int currentPage, int pageSize, User user);
    //用户信息修改
    public void update(User user);
    //雇员个人信息修改
    public void updateEmployeeInfo(EmployeeInfo employeeInfo);
    //雇员状态修改
    public void updateState(int id, int state);
    //雇员薪资修改
    public void updateSalary(int id,float salary);
    //雇员提成修改

    public void updateCommission(int id, float commission);

    int selectId(String username);

    public EmployeeInfo selectByEmployeeId(int id);
}
