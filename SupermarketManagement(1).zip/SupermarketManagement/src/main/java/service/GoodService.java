package service;

import pojo.bean.PageBean;
import pojo.dao.Good;
import java.util.List;

public interface GoodService {
    //查询所有商品(分页查询)
    PageBean<Good> selectByPage(int currentPage, int pageSize);
    //添加商品
    public void add(Good good);
    //根据Id查询商品
    public Good selectById(int id);
    //更改商品信息
    public void update(Good good);
    //根据Id删除商品
    public void deleteById(int id);
    //条件查询(分页)
    PageBean<Good> selectByPageAndCondition(int currentPage,int pageSize,Good good);
    //批量删除
    public void deleteByIds(String[] ids );


    public List<Good> selectHotGood();

    public List<Good> selectGoodSaleNum7();
    public List<Good> selectGoodSaleNum30();
    public List<Good> selectGoodSaleNum365();
}
