package service.impl;

import mapper.GoodMapper;
import mapper.NoticeMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import pojo.dao.Notice;
import service.NoticeService;
import utils.SqlSessionFactoryUtils;

import java.util.List;

public class NoticeServiceImpl implements NoticeService {
    SqlSessionFactory sqlSessionFactory= SqlSessionFactoryUtils.getSqlSessionFactory();
    @Override
    public void addNotice(Notice notice) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        NoticeMapper noticeMapper=sqlSession.getMapper(NoticeMapper.class);
        //调用方法
        noticeMapper.addNotice(notice);
        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    @Override
    public List<Notice> selectAll() {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        NoticeMapper noticeMapper=sqlSession.getMapper(NoticeMapper.class);
        //调用方法
        List<Notice> notices=noticeMapper.selectNotices();
        //释放资源
        sqlSession.close();
        return notices;
    }

    @Override
    public void deleteNotice(int id) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        NoticeMapper noticeMapper=sqlSession.getMapper(NoticeMapper.class);
        noticeMapper.removeNotice(id);
        sqlSession.commit();
        sqlSession.close();
    }

    @Override
    public Notice getNotice(int id) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        NoticeMapper noticeMapper=sqlSession.getMapper(NoticeMapper.class);
        //调用方法
        Notice notice=noticeMapper.selectNotice(id);
        //释放资源
        sqlSession.close();
        return notice;
    }
}
