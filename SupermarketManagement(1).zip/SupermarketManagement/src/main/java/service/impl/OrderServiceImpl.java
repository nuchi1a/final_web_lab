package service.impl;

import mapper.OrderItemMapper;
import mapper.OrdersMapper;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import pojo.dao.OrderItem;
import pojo.dao.Orders;
import service.OrderService;
import utils.SqlSessionFactoryUtils;

import java.util.List;

public class OrderServiceImpl implements OrderService {
    SqlSessionFactory sqlSessionFactory= SqlSessionFactoryUtils.getSqlSessionFactory();
    //购物,提交账单
    public void add(Orders orders){
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        OrdersMapper ordersMapper=sqlSession.getMapper(OrdersMapper.class);
        //调用方法
        ordersMapper.add(orders);
        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }
    public void addItems(OrderItem item){
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        OrderItemMapper itemMapper=sqlSession.getMapper(OrderItemMapper.class);
        //调用方法
        itemMapper.addItems(item);
        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }
    //查询全部账单(管理员用)
    public List<Orders> showAllOrders(){
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        OrdersMapper ordersMapper=sqlSession.getMapper(OrdersMapper.class);
        //调用方法
        List<Orders> list= ordersMapper.selectAllOrders();
        //释放资源
        sqlSession.close();
        return list;
    }
    //查询个人账单（顾客用），根据id查询
    public List<Orders> showOrdersByUserId(int userId){
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        OrdersMapper ordersMapper=sqlSession.getMapper(OrdersMapper.class);
        //调用方法
        List<Orders> list= ordersMapper.selectByUserId(userId);
        //释放资源
        sqlSession.close();
        return list;
    }
    //查询账单详情
    public List<OrderItem> selectOrderItemByOrderId(String orderId){
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        OrderItemMapper itemMapper=sqlSession.getMapper(OrderItemMapper.class);
        //调用方法
        List<OrderItem> list= itemMapper.getOrderItemByOrderId(orderId);
        //释放资源
        sqlSession.close();
        return list;
    }

    @Override
    public void deleteOrder(String orderId) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        OrdersMapper ordersMapper=sqlSession.getMapper(OrdersMapper.class);
        //调用方法
        ordersMapper.deleteById(orderId);
        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    @Override
    public void deleteOrderItem(String orderId) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        OrderItemMapper itemMapper=sqlSession.getMapper(OrderItemMapper.class);
        //调用方法
        itemMapper.deleteByOrderIdAfter(orderId);
        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    @Override
    public void updateStatus(String id, int status) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        OrdersMapper ordersMapper=sqlSession.getMapper(OrdersMapper.class);
        //调用方法
        ordersMapper.updateStatus(id,status);
        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    @Override
    public float selectMoneyInt() {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        OrdersMapper ordersMapper=sqlSession.getMapper(OrdersMapper.class);
        //调用方法
        Float money= ordersMapper.selectMoneyInt();
        if(money==null){
            //释放资源
            sqlSession.close();
            return 0;
        }
        else{
            //释放资源
            sqlSession.close();
            return money;
        }
    }
}
