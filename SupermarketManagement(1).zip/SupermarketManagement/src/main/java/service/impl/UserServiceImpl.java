package service.impl;

import mapper.EmployeeInfoMapper;
import mapper.UserMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import pojo.bean.PageBean;
import pojo.dao.EmployeeInfo;
import pojo.dao.User;
import service.UserService;
import utils.SqlSessionFactoryUtils;

import java.util.List;

public class UserServiceImpl implements UserService {
    SqlSessionFactory sqlSessionFactory= SqlSessionFactoryUtils.getSqlSessionFactory();
    @Override
    public User login(String username, String password, int status) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        UserMapper userMapper=sqlSession.getMapper(UserMapper.class);
        //调用方法
        User user=userMapper.select(username, password,status);
        //提交事务
        sqlSession.close();
        return user;
    }

    @Override
    public boolean register(User user) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        UserMapper userMapper=sqlSession.getMapper(UserMapper.class);
        //调用方法
        User u=userMapper.selectByUsername(user.getUsername());
        //判断user
        if(u==null){
            //用户名不存在，可用
            userMapper.add(user);
            //提交事务
            sqlSession.commit();
        }
        //释放资源
        sqlSession.close();
        return u==null;
    }

    @Override
    public void enter(EmployeeInfo info) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        EmployeeInfoMapper mapper=sqlSession.getMapper(EmployeeInfoMapper.class);
        //调用方法
        mapper.addEmployeeInfo(info);
        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    @Override
    public void deleteById(int id) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        UserMapper userMapper=sqlSession.getMapper(UserMapper.class);
        //调用方法
        userMapper.deleteUserById(id);
        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    @Override
    public void deleteByEmployeeId(int id) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        EmployeeInfoMapper mapper=sqlSession.getMapper(EmployeeInfoMapper.class);
        //调用方法
        mapper.removeEmployeeInfo(id);
        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    @Override
    public int selectNumberByStatus(int status) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        UserMapper userMapper=sqlSession.getMapper(UserMapper.class);
        //调用方法
        int number=userMapper.selectNumberByStatus(status);
        //释放资源
        sqlSession.close();

        return number;
    }

    @Override
    public PageBean<User> selectUsersByPageAndStatus(int currentPage, int pageSize, User user) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        UserMapper userMapper=sqlSession.getMapper(UserMapper.class);

        //计算开始索引
        int begin=(currentPage-1)*pageSize;
        //计算查询条数
        int size=pageSize;



        //查询当前页面数据
        List<User> rows=userMapper.selectByPageAndStatus(begin,size,user);
        //查询总条目数
        int totalCount=userMapper.selectCountByStatus(user);

        //封装PageBean
        PageBean<User> pageBean=new PageBean<>(totalCount,rows);
        //释放资源
        sqlSession.close();
        //返回分页对象
        return pageBean;
    }

    @Override
    public void update(User user) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        UserMapper userMapper=sqlSession.getMapper(UserMapper.class);
        //调用方法
        userMapper.update(user);
        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    @Override
    public void updateEmployeeInfo(EmployeeInfo employeeInfo) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        EmployeeInfoMapper mapper=sqlSession.getMapper(EmployeeInfoMapper.class);
        //调用方法
        mapper.updateEmployeeInfo(employeeInfo);
        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    @Override
    public void updateState(int id, int state) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        EmployeeInfoMapper mapper=sqlSession.getMapper(EmployeeInfoMapper.class);
        //调用方法
        mapper.updateState(id,state);
        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    @Override
    public void updateSalary(int id, float salary) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        EmployeeInfoMapper mapper=sqlSession.getMapper(EmployeeInfoMapper.class);
        //调用方法
        mapper.updateSalary(id,salary);
        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    @Override
    public void updateCommission(int id, float commission) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        EmployeeInfoMapper mapper=sqlSession.getMapper(EmployeeInfoMapper.class);
        //调用方法
        mapper.updateCommission(id,commission);
        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    @Override
    public int selectId(String username) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        UserMapper userMapper=sqlSession.getMapper(UserMapper.class);
        //调用方法
        int id=userMapper.selectIdByUsername(username);
        //释放资源
        sqlSession.close();

        return id;
    }

    @Override
    public EmployeeInfo selectByEmployeeId(int id) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        EmployeeInfoMapper mapper=sqlSession.getMapper(EmployeeInfoMapper.class);
        EmployeeInfo info=mapper.selectEmployeeInfo(id);
        //释放资源
        sqlSession.close();
        return info;
    }


}
