package service.impl;

import mapper.GoodMapper;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import pojo.bean.PageBean;
import pojo.dao.Good;
import service.GoodService;
import utils.SqlSessionFactoryUtils;

import java.util.List;

public class GoodServiceImpl implements GoodService {

    SqlSessionFactory sqlSessionFactory= SqlSessionFactoryUtils.getSqlSessionFactory();
    //分页查询全部商品
    public PageBean<Good> selectByPage(int currentPage, int pageSize){
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        GoodMapper goodMapper=sqlSession.getMapper(GoodMapper.class);
        //计算开始索引
        int begin=(currentPage-1)*pageSize;
        //计算查询条数
        int page=pageSize;

        //查询当前页面数据
        List<Good> rows=goodMapper.selectByPage(begin,page);
        //查询总条目数
        int totalCount=goodMapper.selectTotalCount();

        //封装PageBean
        PageBean<Good> pageBean=new PageBean<>(totalCount,rows);
        //释放资源
        sqlSession.close();
        //返回分页对象
        return pageBean;

    }
    //添加商品
    public void add(Good good){
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        GoodMapper goodMapper=sqlSession.getMapper(GoodMapper.class);
        //调用方法
        goodMapper.add(good);
        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    //根据Id查询商品
    public Good selectById(int id){

        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        GoodMapper goodMapper=sqlSession.getMapper(GoodMapper.class);
        //调用方法
        Good good= goodMapper.selectById(id);
        //释放资源
        sqlSession.close();
        return good;
    }

    public void update(Good good){
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        GoodMapper goodMapper=sqlSession.getMapper(GoodMapper.class);
        //调用方法
        goodMapper.update(good);
        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    public void deleteById(int id){
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        GoodMapper goodMapper=sqlSession.getMapper(GoodMapper.class);
        //调用方法
        goodMapper.deleteById(id);
        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }
    //分页条件查询
    @Override
    public PageBean<Good> selectByPageAndCondition(int currentPage, int pageSize, Good good) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        GoodMapper goodMapper=sqlSession.getMapper(GoodMapper.class);

        //计算开始索引
        int begin=(currentPage-1)*pageSize;
        //计算查询条数
        int size=pageSize;

        //处理brand查询条件，模糊表达式
        String goodName = good.getGoodName();
        if(goodName !=null && goodName.length()>0){
            good.setGoodName("%"+goodName+"%");
        }
        String companyName = good.getCompanyName();
        if(companyName !=null && companyName.length()>0){
            good.setCompanyName("%"+companyName+"%");
        }

        //查询当前页面数据
        List<Good> rows=goodMapper.selectByPageAndCondition(begin,size,good);
        //查询总条目数
        int totalCount=goodMapper.selectTotalCountByCondition(good);

        //封装PageBean
        PageBean<Good> pageBean=new PageBean<>(totalCount,rows);
        //释放资源
        sqlSession.close();
        //返回分页对象
        return pageBean;

    }

    @Override
    public void deleteByIds(String[] ids) {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        GoodMapper goodMapper=sqlSession.getMapper(GoodMapper.class);
        //调用方法
        for(String id : ids) {
            goodMapper.deleteById(Integer.parseInt(id));
        }
        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    @Override
    public List<Good> selectHotGood() {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        GoodMapper goodMapper=sqlSession.getMapper(GoodMapper.class);
        List<Good> goods=goodMapper.selectHotGoods();
        sqlSession.close();
        return goods;

    }

    @Override
    public List<Good> selectGoodSaleNum7() {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        GoodMapper goodMapper=sqlSession.getMapper(GoodMapper.class);
        List<Good> goods=goodMapper.selectGoodsSaleNumber7();
        sqlSession.close();
        return goods;

    }

    @Override
    public List<Good> selectGoodSaleNum30() {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        GoodMapper goodMapper=sqlSession.getMapper(GoodMapper.class);
        List<Good> goods=goodMapper.selectGoodsSaleNumber30();
        sqlSession.close();
        return goods;

    }

    @Override
    public List<Good> selectGoodSaleNum365() {
        //获取SqlSession对象
        SqlSession sqlSession=sqlSessionFactory.openSession();
        //获取mapper
        GoodMapper goodMapper=sqlSession.getMapper(GoodMapper.class);
        List<Good> goods=goodMapper.selectGoodsSaleNumber365();
        sqlSession.close();
        return goods;

    }

}
