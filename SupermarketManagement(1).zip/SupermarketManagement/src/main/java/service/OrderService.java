package service;

import pojo.dao.OrderItem;
import pojo.dao.Orders;

import java.util.List;

public interface OrderService {
    //提交账单
    public void add(Orders orders);
    //提交订单的同时提交订单中的商品内容
    public void addItems(OrderItem item);
    //查询全部账单(管理员用)
    public List<Orders> showAllOrders();
    //查询个人账单（顾客用），根据id查询
    public List<Orders> showOrdersByUserId(int userId);
    //查询账单详情
    public List<OrderItem> selectOrderItemByOrderId(String orderId);
    //删除订单（只能删除已收货的订单，避免误删）
    public void deleteOrder(String orderId);
    //删除订单前要先删除订单项
    public void deleteOrderItem(String orderId);
    //修改订单状态
    public void updateStatus(String id,int status);
    //查询总营收
    public float selectMoneyInt();
}
