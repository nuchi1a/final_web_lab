package utils;

import pojo.dao.Good;
import service.impl.GoodServiceImpl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MyCartUtils {
    //保存商品信息 kry-value:id-商品
    private Map<Integer, Good> cart = new HashMap<Integer, Good>();

    public Map<Integer, Good> getCart() {
        return cart;
    }

    public void setCart(Map<Integer, Good> cart) {
        this.cart = cart;
    }

    //添加购物车
    public void add(Integer id){
        boolean containsKey=cart.containsKey(id);
        //判断是否选入购物车
        if(containsKey){
            //选入
            Good good=cart.get(id);
            good.setBuyNum(good.getBuyNum());
        }
        else{
            //未选入
            Good good=new GoodServiceImpl().selectById(id);
            good.setBuyNum(1);
            cart.put(id,good);
        }
    }
    //删除单件商品
    public void delete(Integer id){
        cart.remove(id);
    }
    //清空购物车
    public void clear(){
        cart.clear();
    }
    //计算总价
    public float totalPrice(){
        Set<Map.Entry<Integer,Good>>set=cart.entrySet();
        Iterator<Map.Entry<Integer,Good>> iterator=set.iterator();
        float total= 0.0f;
        while(iterator.hasNext()){
            Map.Entry<Integer,Good> entry=iterator.next();
            total+=entry.getValue().getBuyNum()*entry.getValue().getSalePrice();
        }
        return total;
    }
    //修改购物车中单件商品数量
    public void updateNum(int id,int num){
        Good good=cart.get(id);
        good.setBuyNum(num);
    }
}
