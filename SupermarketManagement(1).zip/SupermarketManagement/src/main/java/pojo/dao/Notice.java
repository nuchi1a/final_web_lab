package pojo.dao;

import java.util.Date;

public class Notice {
    private Integer nId;
    private String title;
    private String details;
    private String publisher;
    private Date nTime;

    public Notice() {
    }

    public Notice(Integer nId, String title, String details, String publisher, Date nTime) {
        this.nId = nId;
        this.title = title;
        this.details = details;
        this.publisher = publisher;
        this.nTime = nTime;
    }

    public Integer getnId() {
        return nId;
    }

    public void setnId(Integer nId) {
        this.nId = nId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public Date getnTime() {
        return nTime;
    }

    public void setnTime(Date nTime) {
        this.nTime = nTime;
    }

    @Override
    public String toString() {
        return "Notice{" +
                "nId=" + nId +
                ", title='" + title + '\'' +
                ", details='" + details + '\'' +
                ", publisher='" + publisher + '\'' +
                ", nTime=" + nTime +
                '}';
    }
}
