package pojo.dao;

public class EmployeeInfo {
    private Integer employeeId;
    private String name;
    private Integer age;
    private Integer sex;
    private String phone;
    private Integer state;//状态 1.工作 2.下班  3.请假
    private Float salary;
    private Float commission;
    private String job;

    public EmployeeInfo() {
    }

    public EmployeeInfo(Integer employeeId, String name, Integer age, Integer sex, String phone, Integer state, Float salary, Float commission, String job) {
        this.employeeId = employeeId;
        this.name = name;
        this.age = age;
        this.sex = sex;
        this.phone = phone;
        this.state = state;
        this.salary = salary;
        this.commission = commission;
        this.job = job;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Float getSalary() {
        return salary;
    }

    public void setSalary(Float salary) {
        this.salary = salary;
    }

    public Float getCommission() {
        return commission;
    }

    public void setCommission(Float commission) {
        this.commission = commission;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    @Override
    public String toString() {
        return "EmployeeInfo{" +
                "employeeId=" + employeeId +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", sex=" + sex +
                ", phone='" + phone + '\'' +
                ", state=" + state +
                ", salary=" + salary +
                ", commission=" + commission +
                ", job='" + job + '\'' +
                '}';
    }
}
