package pojo.dao;
//订单内的商品项
public class OrderItem {
    String orderId;//对应订单ID
    private Integer goodId;//对应商品ID
    private Integer buyNum;//该商品购买数量

    private Float spend;//每项商品总价格

    public OrderItem() {
    }

    public OrderItem(String orderId, Integer goodId, Integer buyNum, Float spend) {
        this.orderId = orderId;
        this.goodId = goodId;
        this.buyNum = buyNum;
        this.spend = spend;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public Integer getGoodId() {
        return goodId;
    }

    public void setGoodId(Integer goodId) {
        this.goodId = goodId;
    }

    public Integer getBuyNum() {
        return buyNum;
    }

    public void setBuyNum(Integer buyNum) {
        this.buyNum = buyNum;
    }

    public Float getSpend() {
        return spend;
    }

    public void setSpend(Float spend) {
        this.spend = spend;
    }

    @Override
    public String toString() {
        return "OrderItem{" +
                "orderId='" + orderId + '\'' +
                ", goodId=" + goodId +
                ", buyNum=" + buyNum +
                ", spend=" + spend +
                '}';
    }
}
