package pojo.dao;

import java.util.Date;

public class Good {
    private Integer id;//商品id
    private String goodName;//商品名
    private String companyName;//商品供应商名
    private Float salePrice;//销售单价
    private Float inPrice;//进货价格
    private Date inDate;//进货日期
    private Integer num;//库存量
    private String description;//商品简介
    private Integer status;//商品状态（正常、缺货）
    //临时变量，用于购物车，不存入数据库
    private Integer buyNum;
    private Integer totalsalnum;

    public Integer getTotalsalnum() {
        return totalsalnum;
    }

    public void setTotalsalnum(Integer totalsalnum) {
        this.totalsalnum = totalsalnum;
    }

    public Good() {
    }

    public Good(Integer id, String goodName, String companyName, Float salePrice, Float inPrice, Date inDate, Integer num, String description, Integer status, Integer buyNum) {
        this.id = id;
        this.goodName = goodName;
        this.companyName = companyName;
        this.salePrice = salePrice;
        this.inPrice = inPrice;
        this.inDate = inDate;
        this.num = num;
        this.description = description;
        this.status = status;
        this.buyNum = buyNum;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getGoodName() {
        return goodName;
    }

    public void setGoodName(String goodName) {
        this.goodName = goodName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Float getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(Float salePrice) {
        this.salePrice = salePrice;
    }

    public Float getInPrice() {
        return inPrice;
    }

    public void setInPrice(Float inPrice) {
        this.inPrice = inPrice;
    }

    public Date getInDate() {
        return inDate;
    }

    public void setInDate(Date inDate) {
        this.inDate = inDate;
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getBuyNum() {
        return buyNum;
    }

    public void setBuyNum(Integer buyNum) {
        this.buyNum = buyNum;
    }

    @Override
    public String toString() {
        return "Good{" +
                "id=" + id +
                ", goodName='" + goodName + '\'' +
                ", companyName='" + companyName + '\'' +
                ", salePrice=" + salePrice +
                ", inPrice=" + inPrice +
                ", inDate=" + inDate +
                ", num=" + num +
                ", description='" + description + '\'' +
                ", status=" + status +
                ", buyNum=" + buyNum +
                '}';
    }
}
