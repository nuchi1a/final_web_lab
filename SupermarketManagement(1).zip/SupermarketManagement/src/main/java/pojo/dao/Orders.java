package pojo.dao;

import java.util.Date;

//订单类
public class Orders {
    private String id;//订单id
    private Float money;//订单总价格
    private String receiverAddress;//收货地址
    private String receiverName;//收获人姓名
    private String receiverPhone;//收货人电话
    private Date orderTime;//订单生成时间
    private Integer userId;//订单对应的消费者ID
    private Integer status;//订单状态（1.未发货、2.发货、3.接收）

    public Orders() {
    }

    public Orders(String id, Float money, String receiverAddress, String receiverName, String receiverPhone, Date orderTime, Integer userId, Integer status) {
        this.id = id;
        this.money = money;
        this.receiverAddress = receiverAddress;
        this.receiverName = receiverName;
        this.receiverPhone = receiverPhone;
        this.orderTime = orderTime;
        this.userId = userId;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Float getMoney() {
        return money;
    }

    public void setMoney(Float money) {
        this.money = money;
    }

    public String getReceiverAddress() {
        return receiverAddress;
    }

    public void setReceiverAddress(String receiverAddress) {
        this.receiverAddress = receiverAddress;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public String getReceiverPhone() {
        return receiverPhone;
    }

    public void setReceiverPhone(String receiverPhone) {
        this.receiverPhone = receiverPhone;
    }

    public Date getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(Date orderTime) {
        this.orderTime = orderTime;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Orders{" +
                "id='" + id + '\'' +
                ", money=" + money +
                ", receiverAddress='" + receiverAddress + '\'' +
                ", receiverName='" + receiverName + '\'' +
                ", receiverPhone='" + receiverPhone + '\'' +
                ", orderTime=" + orderTime +
                ", userId=" + userId +
                ", status=" + status +
                '}';
    }
}
