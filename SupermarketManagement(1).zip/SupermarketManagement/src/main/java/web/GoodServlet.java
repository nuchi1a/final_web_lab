package web;

import pojo.dao.Good;
import pojo.bean.PageBean;
import service.impl.GoodServiceImpl;
import service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@WebServlet("/good/*")
public class GoodServlet extends BaseServlet {
   private GoodServiceImpl service=new GoodServiceImpl();
   //分页显示所有商品(顾客)
   public void selectByPageC(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
      req.setCharacterEncoding("UTF-8");
      //接收当前页码
      String currentPage=req.getParameter("currentPage");
      String currentPage2 = (String)req.getAttribute("currentPage");
      //接收每页显示条数
      String pageSize=req.getParameter("pageSize");
      String pageSize2 = (String)req.getAttribute("pageSize");
      //调用BrandService进行分页查询
      if(currentPage!=null)
      { PageBean<Good> pageBean=service.selectByPage(Integer.parseInt(currentPage),Integer.parseInt(pageSize));
         //存入req域
         req.setAttribute("pageBeans",pageBean);
         req.setAttribute("currentPage",currentPage);
         req.setAttribute("pageSize",pageSize);
         //转发到goodPage
         req.getRequestDispatcher("/customer/shopping/goodPage.jsp").forward(req, resp);
      }
      else{
         PageBean<Good> pageBean=service.selectByPage(Integer.parseInt(currentPage2),Integer.parseInt(pageSize2));
         //存入req域
         req.setAttribute("pageBeans",pageBean);
         req.setAttribute("currentPage",currentPage2);
         req.setAttribute("pageSize",pageSize2);
         //转发到goodPage
         req.getRequestDispatcher("/customer/shopping/goodPage.jsp").forward(req, resp);
      }


   }
   //分页显示所有商品(管理员)
   public void selectByPageM(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
      req.setCharacterEncoding("UTF-8");
      //接收当前页码
      String currentPage=req.getParameter("currentPage");
      String currentPage2 = (String)req.getAttribute("currentPage");
      //接收每页显示条数
      String pageSize=req.getParameter("pageSize");
      String pageSize2 = (String)req.getAttribute("pageSize");
      //调用BrandService进行分页查询
      if(currentPage!=null)
      { PageBean<Good> pageBean=service.selectByPage(Integer.parseInt(currentPage),Integer.parseInt(pageSize));
         //存入req域
         req.setAttribute("pageBeans",pageBean);
         req.setAttribute("currentPage",currentPage);
         req.setAttribute("pageSize",pageSize);
         //转发到goodPage
         req.getRequestDispatcher("/manager/goods/goodPage.jsp").forward(req, resp);
      }
      else{
         PageBean<Good> pageBean=service.selectByPage(Integer.parseInt(currentPage2),Integer.parseInt(pageSize2));
         //存入req域
         req.setAttribute("pageBeans",pageBean);
         req.setAttribute("currentPage",currentPage2);
         req.setAttribute("pageSize",pageSize2);
         //转发到goodPage
         req.getRequestDispatcher("/manager/goods/goodPage.jsp").forward(req, resp);
      }

   }
   //添加商品
   public void add(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException, ParseException {
      //处理Post中文乱码
      req.setCharacterEncoding("UTF-8");
      //接收数据，封装为brand对象
      String goodName=req.getParameter("goodName");
      String companyName=req.getParameter("companyName");
      String num=req.getParameter("num");
      String description=req.getParameter("description");
      String status=req.getParameter("status");
      String salePrice=req.getParameter("salePrice");
      String inPrice=req.getParameter("inPrice");
      Good good=new Good();
      good.setGoodName(goodName);
      good.setCompanyName(companyName);
      good.setNum(Integer.parseInt(num));
      good.setDescription(description);
      good.setStatus(Integer.parseInt(status));
      good.setSalePrice(Float.parseFloat(salePrice));
      good.setInPrice(Float.parseFloat(inPrice));
      SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

      Date date = new Date(System.currentTimeMillis());

      good.setInDate(date);
      // 调用service
      service.add(good);

      String currentPage="1";
      String pageSize="100";
      req.setAttribute("currentPage",currentPage);
      req.setAttribute("pageSize",pageSize);
      req.getRequestDispatcher("/good/selectByPageM").forward(req,resp);
   }
   //根据ID删除,用于删除商品
   public void deleteById(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
      req.setCharacterEncoding("UTF-8");
      //接收id
      String id=req.getParameter("id");
      service.deleteById(Integer.parseInt(id));
      //转发给查询所有，显示结果
      String currentPage="1";
      String pageSize="100";
      req.setAttribute("currentPage",currentPage);
      req.setAttribute("pageSize",pageSize);
      req.getRequestDispatcher("/good/selectByPageM").forward(req,resp);
   }
   //根据ID查询商品，用于更新修改商品
   public void selectById(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
      //接收id
      String id = req.getParameter("id");
      //调用service
      Good good=service.selectById(Integer.parseInt(id));
      //储存在req中
      req.setAttribute("good",good);
      //转发
      req.getRequestDispatcher("/manager/goods/updateGood.jsp").forward(req, resp);
   }
   //更新修改商品
   public void update(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException, ParseException {
      //处理Post中文乱码
      req.setCharacterEncoding("UTF-8");
      //接收数据，封装为brand对象
      String id=req.getParameter("id");
      String goodName=req.getParameter("goodName");
      String companyName=req.getParameter("companyName");
      String num=req.getParameter("num");
      String description=req.getParameter("description");
      String status=req.getParameter("status");
      String salePrice=req.getParameter("salePrice");
      String inPrice=req.getParameter("inPrice");

      Good good=new Good();
      good.setId(Integer.parseInt(id));
      good.setGoodName(goodName);
      good.setCompanyName(companyName);
      good.setNum(Integer.parseInt(num));
      good.setDescription(description);
      good.setStatus(Integer.parseInt(status));
      good.setSalePrice(Float.parseFloat(salePrice));
      good.setInPrice(Float.parseFloat(inPrice));

      // 调用service
      service.update(good);
      // 转发到selectAllServlet，查看修改结果

      String currentPage="1";
      String pageSize="100";
      req.setAttribute("currentPage",currentPage);
      req.setAttribute("pageSize",pageSize);
      req.getRequestDispatcher("/good/selectByPageM").forward(req,resp);
   }

   //动态条件查询+分页
   public void selectByPageAndConditionC(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
      req.setCharacterEncoding("UTF-8");
      //接收当前页码
      String currentPage=req.getParameter("currentPage");
      //接收每页显示条数
      String pageSize=req.getParameter("pageSize");
      //获取查询条件对象
      Good good=new Good();
      String goodName= req.getParameter("goodName");
      if(goodName!=null){good.setGoodName(goodName);}
      req.setAttribute("goodName",goodName);
      String companyName= req.getParameter("companyName");
      if(companyName!=null){  good.setCompanyName(companyName); }
      req.setAttribute("companyName",companyName);
      String status= req.getParameter("status");
      if(status!=null){ good.setStatus(Integer.parseInt(status)); }
      req.setAttribute("status",status);
      //调用BrandService进行分页查询
      PageBean<Good> pageBean=service.selectByPageAndCondition(Integer.parseInt(currentPage),Integer.parseInt(pageSize),good);
      //存入req域
      req.setAttribute("pageBeans",pageBean);
      req.setAttribute("currentPage",currentPage);
      req.setAttribute("pageSize",pageSize);
      //转发到brandPage
      req.getRequestDispatcher("/customer/shopping/goodPage.jsp").forward(req, resp);
   }
   public void selectByPageAndConditionM(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
      req.setCharacterEncoding("UTF-8");
      //接收当前页码
      String currentPage=req.getParameter("currentPage");
      //接收每页显示条数
      String pageSize=req.getParameter("pageSize");
      //获取查询条件对象
      Good good=new Good();
      String goodName= req.getParameter("goodName");
      if(goodName!=null){good.setGoodName(goodName);}
      req.setAttribute("goodName",goodName);
      String companyName= req.getParameter("companyName");
      if(companyName!=null){  good.setCompanyName(companyName); }
      req.setAttribute("companyName",companyName);
      String status= req.getParameter("status");
      if(status!=null){ good.setStatus(Integer.parseInt(status)); }
      req.setAttribute("status",status);
      //调用BrandService进行分页查询
      PageBean<Good> pageBean=service.selectByPageAndCondition(Integer.parseInt(currentPage),Integer.parseInt(pageSize),good);
      //存入req域
      req.setAttribute("pageBeans",pageBean);
      req.setAttribute("currentPage",currentPage);
      req.setAttribute("pageSize",pageSize);
      //转发到brandPage
      req.getRequestDispatcher("/manager/goods/goodPage.jsp").forward(req, resp);
   }
   public void deleteByIds(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
      //获取所有id
      String[] ids = req.getParameterValues("uid");
      //调用service删除
      service.deleteByIds(ids);
      //跳转查询所有servlet
      resp.sendRedirect("/SupermarketManagement/good/selectByPageM?currentPage=1&pageSize=20");

   }

   public void selectHotGoods(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
     List<Good> goods= service.selectHotGood();
      req.setAttribute("hotGoods",goods);
      req.getRequestDispatcher("/customer/shopping/hotSale.jsp").forward(req,resp);
   }
   public void selectGoodSaleNumber(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
      String days= req.getParameter("goodsale");
      int d=Integer.parseInt(days);
      if(d==1)
      {
         List<Good> goods= service.selectGoodSaleNum7();
         req.setAttribute("hotGoods",goods);
      }
      if(d==2){
         List<Good> goods= service.selectGoodSaleNum30();
         req.setAttribute("hotGoods",goods);
      }
      if(d==3){
         List<Good> goods= service.selectGoodSaleNum365();
         req.setAttribute("hotGoods",goods);
      }
      req.getRequestDispatcher("/customer/shopping/hotSale.jsp").forward(req,resp);
   }
}