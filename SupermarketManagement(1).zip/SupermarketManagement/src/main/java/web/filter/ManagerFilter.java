package web.filter;

import pojo.dao.User;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter("/manager/*")
//判断是否时管理员
public class ManagerFilter implements Filter {
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        //判断访问路径是否何登陆注册相关，允许注册相关文件被使用
        String requestURL[] = {"/login.jsp","/register.jsp","/users/login","/users/register"};
        String url=httpServletRequest.getRequestURL().toString();
        for(String s:requestURL){
            if(url.contains(s)){
                chain.doFilter(request, response);
                return;
            }
        }
        //过滤
        HttpSession session = httpServletRequest.getSession();
        User user=(User)session.getAttribute("user");

        if(user.getStatus()==2){
            chain.doFilter(request, response);
        }
        else if(user.getStatus()!=2)
        {
            request.setAttribute("loginMsg2","你不是管理员");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }
    public void init(FilterConfig filterConfig) throws ServletException {

    }
    public void destroy() {

    }
}
