package web.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter("/*")
//判断是否登录
public class LoginFilter implements Filter {
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        //判断访问路径是否何登陆注册相关，允许注册相关文件被使用
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        String requestURL[] = {"/login.jsp","/register.jsp","/users/login","/users/register","/01.html"};
        String url=httpServletRequest.getRequestURL().toString();
        for(String s:requestURL){
            if(url.contains(s)){
                chain.doFilter(request, response);
                return;
            }
        }

        //过滤
        HttpSession session = httpServletRequest.getSession();
        Object user=session.getAttribute("user");

        if(user!=null){
            chain.doFilter(request, response);
        }
        else if(user==null)
        {
            request.setAttribute("loginMsg","你尚未登陆");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }
    public void init(FilterConfig filterConfig) throws ServletException {

    }
    public void destroy() {

    }
}
