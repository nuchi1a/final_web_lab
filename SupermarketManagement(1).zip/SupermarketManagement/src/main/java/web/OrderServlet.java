package web;

import pojo.dao.Good;
import pojo.dao.OrderItem;
import pojo.dao.Orders;
import pojo.dao.User;
import service.impl.GoodServiceImpl;
import service.impl.OrderServiceImpl;
import utils.MyCartUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@WebServlet("/order/*")
public class OrderServlet extends BaseServlet {
   OrderServiceImpl service=new OrderServiceImpl();
   //提交订单
   public void addOrder(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
      req.setCharacterEncoding("UTF-8");
      //使用会话中的用户
      HttpSession session = req.getSession();
      User user=(User)session.getAttribute("user");
      //使用会话中的购物车
      MyCartUtils myCart= (MyCartUtils) req.getSession().getAttribute("myCart");
      //获取顾客发送的收件地址、收件人与联系方式
      String address= req.getParameter("receiverAddress");
      String receiverName=req.getParameter("receiverName");
      String phone=req.getParameter("receiverPhone");
         String Id = UUID.randomUUID().toString(); //获取唯一ID标识
         //获取账单实例
         Orders orders = new Orders();
         orders.setId(Id);
         orders.setUserId(user.getId());
         orders.setReceiverPhone(phone);
         SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss z");
         Date date = new Date(System.currentTimeMillis());
         orders.setOrderTime(date);
         orders.setMoney(myCart.totalPrice());
         orders.setReceiverAddress(address);
         orders.setReceiverName(receiverName);
         orders.setStatus(1);
         //调用服务，先载入表单
         service.add(orders);
         //获取账单中货物实例，并将表单中的货物信息一起载入
         for (Integer id : myCart.getCart().keySet()) {
            OrderItem item = new OrderItem();
            item.setOrderId(orders.getId());
            item.setBuyNum(myCart.getCart().get(id).getBuyNum());
            item.setGoodId(myCart.getCart().get(id).getId());
            item.setSpend(myCart.getCart().get(id).getSalePrice()*myCart.getCart().get(id).getBuyNum());
            service.addItems(item);
         }
         //清理购物车
         myCart.clear();
         String orderMsg="账单提交成功";
         req.setAttribute("orderMsg",orderMsg);
         //转回菜单
         req.getRequestDispatcher("/customer/menu.jsp").forward(req, resp);

   }
   //查询个人账单
   public void selectByUserId(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
      req.setCharacterEncoding("UTF-8");
      //使用会话中的用户
      HttpSession session = req.getSession();
      User user=(User)session.getAttribute("user");
      //调用BrandService进行查询
      List<Orders> orders=service.showOrdersByUserId(user.getId());
      //存入req域
      req.setAttribute("orders",orders);
      //转发到bill.jsp，显示账单记录
      req.getRequestDispatcher("/customer/ordered/bill.jsp").forward(req,resp);
   }
   //管理员查询个人账单
   public void selectByUserIdM(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
      req.setCharacterEncoding("UTF-8");
      //接收指定用户Id
      String userId= req.getParameter("userId");
      //调用BrandService进行查询
      List<Orders> orders=service.showOrdersByUserId(Integer.parseInt(userId));
      //存入req域
      req.setAttribute("orders",orders);
      //转发到bill.jsp，显示账单记录
      req.getRequestDispatcher("/manager/orders/bills.jsp").forward(req,resp);
   }
   //查询所有账单
   public void showAllOrders(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
      req.setCharacterEncoding("UTF-8");
      //调用OrderService进行查询
      List<Orders> orders=service.showAllOrders();
      //存入req域
      req.setAttribute("orders",orders);
      //显示账单记录
      req.getRequestDispatcher("/manager/orders/bills.jsp").forward(req,resp);
   }
   //查询账单详情
   public void selectOrderItemByOrderId(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
      req.setCharacterEncoding("UTF-8");
      String OrderId= req.getParameter("OrderId");
      //调用OrderItemService进行查询
      List<OrderItem> orderItems=service.selectOrderItemByOrderId(OrderId);
      List<Good>goods=new ArrayList<Good>();
      GoodServiceImpl goodService=new GoodServiceImpl();
      for(OrderItem orderItem : orderItems){
         Good good=goodService.selectById(orderItem.getGoodId());
         good.setBuyNum(orderItem.getBuyNum());
         good.setSalePrice(orderItem.getSpend());
         goods.add(good);
      }
      //存入req域
      req.setAttribute("goods",goods);
      //转发到orderItem.jsp，显示账单详情
      req.getRequestDispatcher("/customer/ordered/billInfo.jsp").forward(req,resp);
   }
   //查询账单详情
   public void selectOrderItemByOrderIdM(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
      req.setCharacterEncoding("UTF-8");
      String OrderId= req.getParameter("OrderId");
      //调用OrderItemService进行查询
      List<OrderItem> orderItems=service.selectOrderItemByOrderId(OrderId);
      List<Good>goods=new ArrayList<Good>();
      GoodServiceImpl goodService=new GoodServiceImpl();
      for(OrderItem orderItem : orderItems){
         Good good=goodService.selectById(orderItem.getGoodId());
         good.setBuyNum(orderItem.getBuyNum());
         good.setSalePrice(orderItem.getSpend());
         goods.add(good);
      }
      //存入req域
      req.setAttribute("goods",goods);
      //转发到orderItem.jsp，显示账单详情
      req.getRequestDispatcher("/manager/orders/billInfo.jsp").forward(req,resp);
   }
   //根据账单ID删除单个账单
   public void deleteOrderC(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
      req.setCharacterEncoding("UTF-8");
      String OrderId= req.getParameter("OrderId");
      //调用OrderService进行删除，先删账单对应的账单内部项，再删账单
      service.deleteOrderItem(OrderId);
      service.deleteOrder(OrderId);
      //转发到menu.jsp，显示账单记录
      resp.sendRedirect("/SupermarketManagement/order/selectByUserId");
   }
   //根据账单ID删除单个账单
   public void deleteOrderM(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
      req.setCharacterEncoding("UTF-8");
      String OrderId= req.getParameter("OrderId");
      //调用OrderService进行删除，先删账单对应的账单内部项，再删账单
      service.deleteOrderItem(OrderId);
      service.deleteOrder(OrderId);
      //转发到menu.jsp，显示账单记录
      resp.sendRedirect("/SupermarketManagement/order/showAllOrders");
   }
   public void updateOrderStatusC(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
      req.setCharacterEncoding("UTF-8");
      String OrderId= req.getParameter("OrderId");
      int status=3;
      service.updateStatus(OrderId,status);
      resp.sendRedirect("/SupermarketManagement/order/selectByUserId");
   }
   public void updateOrderStatusM(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
      req.setCharacterEncoding("UTF-8");
      String OrderId= req.getParameter("OrderId");
      int status=2;
      service.updateStatus(OrderId,status);
      //发货后修改库存
      GoodServiceImpl goodService=new GoodServiceImpl();
      List<OrderItem> items=service.selectOrderItemByOrderId(OrderId);
      for(OrderItem item : items){
         Good good=goodService.selectById(item.getGoodId());
         good.setNum(good.getNum()-item.getBuyNum());
         if(good.getNum()<0){
            good.setStatus(2);
         }
         goodService.update(good);
      }
      //转发
      resp.sendRedirect("/SupermarketManagement/order/showAllOrders");
   }
   public void selectSumMoney(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
      req.setCharacterEncoding("UTF-8");
      float sumMoney=service.selectMoneyInt();
      req.setAttribute("sumMoney", sumMoney);
      req.getRequestDispatcher("/manager/revenue.jsp").forward(req, resp);

   }
}