package web;

import pojo.bean.PageBean;
import pojo.dao.EmployeeInfo;
import pojo.dao.User;
import service.impl.UserServiceImpl;
import utils.MyCartUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/users/*")
public class UserServlet extends BaseServlet {
    private UserServiceImpl service=new UserServiceImpl();
    public void login(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        req.setCharacterEncoding("UTF-8");
        //获取username与password
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String status = req.getParameter("status");
        User user= service.login(username,password,Integer.parseInt(status));
        resp.setContentType("text/html;charset=utf-8");
        HttpSession session = req.getSession();
        session.setAttribute("user", user);
        //判断user
        if(user!=null){
            if(user.getStatus()==1) { //登陆成功，会话中载入user，通过过滤器访问其他功能页面
                //顾客载入购物车信息
                MyCartUtils myCart = new MyCartUtils();
                session.setAttribute("myCart", myCart);
                resp.sendRedirect("/SupermarketManagement/customer/menu.jsp");
            }
            if(user.getStatus()==2){
                resp.sendRedirect("/SupermarketManagement/manager/menu.jsp");
            }
            if(user.getStatus()==3){
                resp.sendRedirect("/SupermarketManagement/employee/menu.jsp");
            }
        }else {
            //登陆失败
            String loginMsg="登陆失败，用户名或密码错误";
            req.setAttribute("loginMsg",loginMsg);
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
        }
    }
    public void register(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        req.setCharacterEncoding("UTF-8");
        //接收用户数据
        String username=req.getParameter("username");
        String password=req.getParameter("password");
        String email=req.getParameter("email");
        String status=req.getParameter("status");
        int s=Integer.parseInt(status);
        //封装用户对象
        User user=new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setEmail(email);
        user.setStatus(s);
        boolean flag= service.register(user);
        //判断user
        if(flag){
            if(s==3){
                req.setAttribute("username2",username);
                req.getRequestDispatcher("/manager/employ/addEmployeeInfo.jsp").forward(req, resp);//雇员注册
            }
            else {
                //注册成功
                String registerMsg = "注册成功";
                req.setAttribute("registerMsg", registerMsg);
                req.getRequestDispatcher("/login.jsp").forward(req, resp);
            }

        }else {
            //用户名存在，不可添加用户
            String registerMsg="用户名存在，注册失败";
            req.setAttribute("registerMsg",registerMsg);
            if(s==1) {
                req.getRequestDispatcher("/register.jsp").forward(req, resp);//用户注册
            }
            if(s==2){
                req.getRequestDispatcher("/manager/register.jsp").forward(req, resp);//管理员注册
            }
            if(s==3){
                req.getRequestDispatcher("/manager/addEmployeeInfo.jsp").forward(req, resp);//雇员注册
            }
        }
    }
    public void addEmployeeInfo(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        req.setCharacterEncoding("UTF-8");
        //接收用户数据
        String username=req.getParameter("username");
        int employeeId=service.selectId(username);
        String phone=req.getParameter("phone");
        String name=req.getParameter("name");
        String age=req.getParameter("age");
        String sex=req.getParameter("sex");
        String state=req.getParameter("state");
        String salary=req.getParameter("salary");
        String commission=req.getParameter("commission");
        String job=req.getParameter("job");

        EmployeeInfo employeeInfo=new EmployeeInfo();
        employeeInfo.setEmployeeId(employeeId);
        employeeInfo.setAge(Integer.parseInt(age));
        employeeInfo.setCommission(Float.parseFloat(commission));
        employeeInfo.setName(name);
        employeeInfo.setPhone(phone);
        employeeInfo.setSalary(Float.parseFloat(salary));
        employeeInfo.setSex(Integer.parseInt(sex));
        employeeInfo.setState(Integer.parseInt(state));
        employeeInfo.setJob(job);

        service.enter(employeeInfo);
        resp.sendRedirect("/SupermarketManagement/manager/employ/addEmployee.jsp");
    }
    public void logoff(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        HttpSession session = req.getSession();
        User user=(User)session.getAttribute("user");
        if(user.getStatus()==1) {
            service.deleteById(user.getId());
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
        }
        if(user.getStatus()==2){
            if(service.selectNumberByStatus(2)>1){
                service.deleteById(user.getId());
                req.getRequestDispatcher("/login.jsp").forward(req, resp);
            }else{
                String message="不可删除所有管理员";
                req.setAttribute("message", message);
                req.getRequestDispatcher("/manager/menu.jsp").forward(req,resp);
            }
        }
    }
    //查询用户（分页+动态条件查询）
    public void selectUser(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        req.setCharacterEncoding("UTF-8");
        //接收当前页码
        String currentPage=req.getParameter("currentPage");
        //接收每页显示条数
        String pageSize=req.getParameter("pageSize");
        //获取查询条件对象
        User user=new User();
        String status= req.getParameter("status");
        if(status!=null){ user.setStatus(Integer.parseInt(status));
            System.out.println(Integer.parseInt(status));}
        //调用BrandService进行分页查询
        PageBean<User> pageBean=service.selectUsersByPageAndStatus(Integer.parseInt(currentPage),Integer.parseInt(pageSize),user);
        //存入req域
        req.setAttribute("pageBeans",pageBean);
        req.setAttribute("currentPage",currentPage);
        req.setAttribute("status",status);
        req.setAttribute("pageSize",pageSize);
        //转发到brandPage
        req.getRequestDispatcher("/manager/userPage.jsp").forward(req, resp);
    }
    public void updateUser(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        //处理Post中文乱码
        req.setCharacterEncoding("UTF-8");
        //接收数据，封装为brand对象
        String id=req.getParameter("id");
        String username=req.getParameter("username");
        String password=req.getParameter("password");
        String email=req.getParameter("email");
        String status=req.getParameter("status");
        User user=new User();
        user.setId(Integer.parseInt(id));
        user.setUsername(username);
        user.setPassword(password);
        user.setEmail(email);
        user.setStatus(Integer.parseInt(status));
        // 调用service
        service.update(user);
        String updateMsg="修改个人信息成功";
        if(user.getStatus()==1) {
            req.setAttribute("updateMsg",updateMsg);
            req.getRequestDispatcher("/customer/menu.jsp").forward(req,resp);
        }
        if(user.getStatus()==2){
            req.setAttribute("updateMsg",updateMsg);
            req.getRequestDispatcher("/manager/menu.jsp").forward(req,resp);
        }
        if(user.getStatus()==3){
            req.setAttribute("updateMsg",updateMsg);
            req.getRequestDispatcher("/employee/menu.jsp").forward(req,resp);
        }
    }

    public void selectEmployeeInfoById(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        req.setCharacterEncoding("UTF-8");
        String id=req.getParameter("eId");
        int f=Integer.parseInt(req.getParameter("f"));
        HttpSession session = req.getSession();
        User user=(User)session.getAttribute("user");

        EmployeeInfo info= service.selectByEmployeeId(Integer.parseInt(id));
        req.setAttribute("info",info);
        if(f==1)
        {
            int status=user.getStatus();
            req.setAttribute("status",status);
            req.getRequestDispatcher("/employee/PersonInfo.jsp").forward(req, resp);
        }
        if(f==2)
        {
            float salary=info.getSalary();
            float commission=info.getCommission();
            req.setAttribute("eId",id);
            req.setAttribute("salary",salary);
            req.setAttribute("commission",commission);
            req.getRequestDispatcher("/manager/employ/updateSAndC.jsp").forward(req,resp);
        }

    }
}