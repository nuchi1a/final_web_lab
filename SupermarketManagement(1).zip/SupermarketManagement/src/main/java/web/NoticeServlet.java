package web;

import pojo.bean.PageBean;
import pojo.dao.EmployeeInfo;
import pojo.dao.Notice;
import pojo.dao.User;
import service.impl.NoticeServiceImpl;
import service.impl.UserServiceImpl;
import utils.MyCartUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

@WebServlet("/notice/*")
public class NoticeServlet extends BaseServlet {
    private NoticeServiceImpl service=new NoticeServiceImpl();
    public void add(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException, ParseException{
        //处理Post中文乱码
        req.setCharacterEncoding("UTF-8");
        String title=req.getParameter("title");
        String details=req.getParameter("details");

        HttpSession session = req.getSession();
        User user=(User)session.getAttribute("user");
        Date date = new Date(System.currentTimeMillis());
        Notice notice=new Notice();
        notice.setTitle(title);
        notice.setDetails(details);
        notice.setPublisher(user.getUsername());
        notice.setnTime(date);
        service.addNotice(notice);
        resp.sendRedirect("/SupermarketManagement/manager/menu.jsp");
    }
    public void selectById(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException, ParseException{
        //处理Post中文乱码
        req.setCharacterEncoding("UTF-8");
        String id=req.getParameter("nId");
        Notice notice=service.getNotice(Integer.parseInt(id));
        String status=req.getParameter("status");
        req.setAttribute("notice",notice);
        req.setAttribute("status",status);
        req.getRequestDispatcher("/employee/noticeInfo.jsp").forward(req,resp);

    }
    public void selectAll(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException, ParseException{
        //处理Post中文乱码
        req.setCharacterEncoding("UTF-8");
        List<Notice> notices=service.selectAll();
        HttpSession session = req.getSession();
        User user=(User)session.getAttribute("user");
        req.setAttribute("notices",notices);
        req.setAttribute("status",user.getStatus());
        req.getRequestDispatcher("/employee/noticePage.jsp").forward(req,resp);
    }
    public void deleteById(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException, ParseException{
        req.setCharacterEncoding("UTF-8");
        //接收id
        String id=req.getParameter("nId");
        service.deleteNotice(Integer.parseInt(id));
        //转发给查询所有，显示结果
        resp.sendRedirect("/SupermarketManagement/notice/selectAll");
    }
}