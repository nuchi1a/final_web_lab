package web;

import pojo.bean.PageBean;
import pojo.dao.EmployeeInfo;
import pojo.dao.User;
import service.impl.UserServiceImpl;
import utils.MyCartUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/ep/*")
public class EmployeeServlet extends BaseServlet {
    private UserServiceImpl service=new UserServiceImpl();
    public void selectById(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        req.setCharacterEncoding("UTF-8");
        HttpSession session = req.getSession();
        User user=(User)session.getAttribute("user");
        int id=user.getId();
        int status=user.getStatus();
        EmployeeInfo info= service.selectByEmployeeId(id);
        req.setAttribute("info",info);
        req.setAttribute("status",status);
        req.getRequestDispatcher("/employee/updatePersonInfo.jsp").forward(req,resp);

    }
    public void updatePersonInfo(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        //处理Post中文乱码
        req.setCharacterEncoding("UTF-8");

        String employeeId=req.getParameter("employeeId");
        String phone=req.getParameter("phone");
        String name=req.getParameter("name");
        String age=req.getParameter("age");
        String sex=req.getParameter("sex");
        String state=req.getParameter("state");
        String job=req.getParameter("job");

        EmployeeInfo employeeInfo=new EmployeeInfo();
        employeeInfo.setEmployeeId(Integer.parseInt(employeeId));
        employeeInfo.setAge(Integer.parseInt(age));
        employeeInfo.setName(name);
        employeeInfo.setPhone(phone);
        employeeInfo.setSex(Integer.parseInt(sex));
        employeeInfo.setState(Integer.parseInt(state));
        employeeInfo.setJob(job);

        service.updateEmployeeInfo(employeeInfo);
        String updateMsg="修改成功";
        req.setAttribute("updateMsg2",updateMsg);
       req.getRequestDispatcher("/employee/menu.jsp").forward(req,resp);
    }
    public void selectInfoById(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        //处理Post中文乱码
        req.setCharacterEncoding("UTF-8");
        HttpSession session = req.getSession();
        User user=(User)session.getAttribute("user");
        int id=user.getId();
        EmployeeInfo info= service.selectByEmployeeId(id);
        req.setAttribute("info",info);
        req.getRequestDispatcher("/employee/PersonInfo.jsp").forward(req,resp);

    }
    public void logoff(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        //处理Post中文乱码
        req.setCharacterEncoding("UTF-8");
        HttpSession session = req.getSession();
        User user=(User)session.getAttribute("user");
        service.deleteByEmployeeId(user.getId());
        service.deleteById(user.getId());

        resp.sendRedirect("/SupermarketManagement/login.jsp");

    }
    public void signIn(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        //处理Post中文乱码
        req.setCharacterEncoding("UTF-8");
        HttpSession session = req.getSession();
        User user=(User)session.getAttribute("user");
        String state=req.getParameter("state");
        service.updateState(user.getId(), Integer.parseInt(state));
        String signInMsg="打卡成功";
        req.setAttribute("signInMsg", signInMsg);
        req.getRequestDispatcher("/employee/menu.jsp").forward(req,resp);
    }
    public void signOut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        //处理Post中文乱码
        req.setCharacterEncoding("UTF-8");
        HttpSession session = req.getSession();
        User user=(User)session.getAttribute("user");
        String state=req.getParameter("state");
        service.updateState(user.getId(), Integer.parseInt(state));
        String signOutMsg="签退成功";
        req.setAttribute("signOutMsg", signOutMsg);
        req.getRequestDispatcher("/employee/menu.jsp").forward(req,resp);
    }
    public void updateSalaryAndCommission(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        //处理Post中文乱码
        req.setCharacterEncoding("UTF-8");
        String id=req.getParameter("eId");
        String salary=req.getParameter("salary");
        String commission=req.getParameter("commission");
        service.updateCommission(Integer.parseInt(id), Float.parseFloat(commission));
        service.updateSalary(Integer.parseInt(id), Float.parseFloat(salary));;
        resp.sendRedirect("/SupermarketManagement/users/selectUser?currentPage=1&pageSize=10&status=3");

    }

}