package web;

import utils.MyCartUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/cart/*")
public class CartServlet extends BaseServlet {

    public void addCart(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        //接收id
        String id = req.getParameter("id");
        //使用会话中的购物车
        MyCartUtils myCart= (MyCartUtils) req.getSession().getAttribute("myCart");
        //添加
        myCart.add(Integer.parseInt(id));
        req.getRequestDispatcher("/customer/shopping/cart.jsp").forward(req, resp);
    }
    public void showCart(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{
        req.getRequestDispatcher("/customer/shopping/cart.jsp").forward(req,resp);
    }
    public void deleteCart(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{
        //接收id
        String id = req.getParameter("id");
        //使用会话中的购物车
        MyCartUtils myCart= (MyCartUtils) req.getSession().getAttribute("myCart");
        //使用删除方法
        myCart.delete(Integer.parseInt(id));
        req.getRequestDispatcher("/customer/shopping/cart.jsp").forward(req, resp);
    }
    public void clearCart(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{
        //使用会话中的购物车
        MyCartUtils myCart= (MyCartUtils) req.getSession().getAttribute("myCart");
        //使用清空
        myCart.clear();
        req.getRequestDispatcher("/customer/shopping/cart.jsp").forward(req, resp);
    }
    public void updateCart(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{
        //接收id与购买数量
        String id = req.getParameter("id");
        String buyNum=req.getParameter("buyNum");

        //使用方法
        if(buyNum==null){
            System.out.println("buyNum is null");
        }
        else
        {
            if(Integer.parseInt(buyNum)>=0) {
            //使用会话中的购物车
            MyCartUtils myCart= (MyCartUtils) req.getSession().getAttribute("myCart");
            myCart.updateNum(Integer.parseInt(id), Integer.parseInt(buyNum));
            req.getRequestDispatcher("/customer/shopping/cart.jsp").forward(req, resp);
        }
        else{
            String cartMsg="商品数量不能为负值";
            req.setAttribute("cartMsg",cartMsg);
            req.getRequestDispatcher("/customer/shopping/cart.jsp").forward(req, resp);
        }
        }
    }
}